-- Cjdns admin module for Lua
-- Written by Philip Horger

-- This table is preserved over multiple imports, and collects
-- submodules import-by-import via init.lua.

return {}
